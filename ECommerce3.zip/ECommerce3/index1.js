
const express = require("express");
const path = require("path");

const app = express();

const loginData = require("../ECommerce3/routes/routes");
const routeRouter = require("../ECommerce3/routes/app");
// const bookingData = require("../routes/booking")

app.use(loginData);
app.use(routeRouter);
// app.use(bookingData);

app.listen(3030, ()=>{
    console.log("Server Started in 3030");
})